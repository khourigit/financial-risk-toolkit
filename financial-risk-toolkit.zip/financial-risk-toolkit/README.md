# Financial Risk Toolkit

A small, independently developed, open-source Python library for educational portfolio and market-risk analysis. **Not investment advice.**

## Features

- Historical Value at Risk (VaR), using nearest-rank lower-tail empirical quantiles
- Conditional Value at Risk (CVaR), averaging observations at or below the VaR cutoff (including ties)
- Annualised Sharpe and Sortino ratios
- Maximum drawdown
- Portfolio volatility from a covariance matrix

## Installation

```bash
python -m pip install -e .
```

## Example

```python
from financial_risk_toolkit import historical_var, maximum_drawdown

returns = [-0.05, 0.01, -0.02, 0.03, 0.005]
print(historical_var(returns, confidence=0.95))
print(maximum_drawdown([100, 110, 99, 120]))
```

## Testing

```bash
python -m unittest discover -s tests -v
```

## Scope and limitations

Metrics use population volatility and per-period input returns. VaR and CVaR use a simple discrete historical convention; different software packages may use interpolated quantiles or different tail definitions. This package does not estimate future risk, validate covariance matrices as positive-semidefinite, or provide financial advice. Contributions and issue reports are welcome.

## Licence

MIT. See `LICENSE`.
