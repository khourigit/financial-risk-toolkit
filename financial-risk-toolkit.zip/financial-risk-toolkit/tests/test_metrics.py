import unittest
from financial_risk_toolkit import historical_var, conditional_var, sharpe_ratio, sortino_ratio, maximum_drawdown, portfolio_volatility

class MetricsTests(unittest.TestCase):
    def test_var(self):
        self.assertAlmostEqual(historical_var([-0.10, -0.04, 0.01, 0.03], 0.75), 0.10)
    def test_cvar(self):
        self.assertAlmostEqual(conditional_var([-0.10, -0.04, 0.01, 0.03], 0.75), 0.10)
    def test_drawdown(self):
        self.assertAlmostEqual(maximum_drawdown([100, 120, 90, 110]), 0.25)
    def test_volatility(self):
        self.assertAlmostEqual(portfolio_volatility([0.5, 0.5], [[0.04,0],[0,0.09]]), (0.0325)**0.5)
    def test_ratios(self):
        self.assertTrue(isinstance(sharpe_ratio([0.01, -0.02, 0.03]), float))
        self.assertTrue(isinstance(sortino_ratio([0.01, -0.02, 0.03]), float))
    def test_empty(self):
        with self.assertRaises(ValueError):
            historical_var([])

if __name__ == '__main__':
    unittest.main()
