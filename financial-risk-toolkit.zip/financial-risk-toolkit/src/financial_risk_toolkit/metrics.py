"""Educational financial risk analytics; not investment advice."""
from math import sqrt
from statistics import mean, pstdev


def _returns(values):
    values = [float(v) for v in values]
    if not values:
        raise ValueError('returns cannot be empty')
    if any(not (-float('inf') < v < float('inf')) for v in values):
        raise ValueError('returns must be finite')
    return values


def historical_var(returns, confidence=0.95):
    """Positive loss threshold at the empirical lower-tail quantile (nearest rank)."""
    r = sorted(_returns(returns))
    if not 0 < confidence < 1:
        raise ValueError('confidence must be between 0 and 1')
    from math import ceil
    index = max(0, ceil((1-confidence)*len(r))-1)
    return max(0.0, -r[index])


def conditional_var(returns, confidence=0.95):
    """Mean loss among observations at or below the empirical VaR cutoff."""
    r = _returns(returns)
    cutoff = -historical_var(r, confidence)
    tail = [x for x in r if x <= cutoff]
    return max(0.0, -mean(tail))


def sharpe_ratio(returns, risk_free_rate=0.0, periods_per_year=252):
    """Annualised Sharpe ratio; rates are per observation."""
    r = _returns(returns)
    sd = pstdev(r)
    if sd == 0 or periods_per_year <= 0:
        raise ValueError('volatility and periods_per_year must be positive')
    return sqrt(periods_per_year) * (mean(r)-risk_free_rate)/sd


def sortino_ratio(returns, target_return=0.0, periods_per_year=252):
    """Annualised Sortino ratio using downside deviation about target."""
    r = _returns(returns)
    if periods_per_year <= 0:
        raise ValueError('periods_per_year must be positive')
    downside = sqrt(mean([min(0, x-target_return)**2 for x in r]))
    if downside == 0:
        raise ValueError('downside deviation is zero')
    return sqrt(periods_per_year)*(mean(r)-target_return)/downside


def maximum_drawdown(equity_curve):
    """Maximum peak-to-trough fractional loss for positive equity values."""
    values = [float(v) for v in equity_curve]
    if not values or any(v <= 0 or v == float('inf') for v in values):
        raise ValueError('equity values must be finite and positive')
    peak = values[0]
    worst = 0.0
    for value in values:
        peak = max(peak, value)
        worst = max(worst, (peak-value)/peak)
    return worst


def portfolio_volatility(weights, covariance_matrix):
    """Portfolio standard deviation from weights and a covariance matrix."""
    w = [float(x) for x in weights]
    c = [[float(x) for x in row] for row in covariance_matrix]
    n = len(w)
    if not n or len(c) != n or any(len(row) != n for row in c):
        raise ValueError('covariance matrix dimensions must match weights')
    variance = sum(w[i]*c[i][j]*w[j] for i in range(n) for j in range(n))
    if variance < -1e-12:
        raise ValueError('negative portfolio variance')
    return sqrt(max(0, variance))
